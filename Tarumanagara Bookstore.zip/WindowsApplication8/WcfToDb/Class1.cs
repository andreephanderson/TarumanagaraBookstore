﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace WcfToDb
{
    [DataContract]
    public class Class1
    {
        [DataMember]
        public string id { get; set; }

        [DataMember]
        public string judul_buku { get; set; }

        [DataMember]
        public string nama_penulis { get; set; }

        [DataMember]
        public string nama_penerbit { get; set; }

        [DataMember]
        public string tanggal_terbit { get; set; }

        [DataMember]
        public int harga { get; set; }

        [DataMember]
        public string status { get; set; }
    }
}
