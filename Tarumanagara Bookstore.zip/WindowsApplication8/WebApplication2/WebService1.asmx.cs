﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebApplication2
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public DataTable GetBiodata()
        {
            DataSet1TableAdapters.List_AdminTableAdapter ds = new DataSet1TableAdapters.List_AdminTableAdapter();
            return ds.GetData();
        }

        [WebMethod]
        public DataTable GetListNewBook()
        {
            DataSet1TableAdapters.Tabel_User1TableAdapter ds = new DataSet1TableAdapters.Tabel_User1TableAdapter();
            return ds.GetData();
        }

        [WebMethod]
        public DataTable GetBiodataUser()
        {
            DataSet1TableAdapters.Tabel_UserTableAdapter ds = new DataSet1TableAdapters.Tabel_UserTableAdapter();
            return ds.GetData();
        }
    }
}
