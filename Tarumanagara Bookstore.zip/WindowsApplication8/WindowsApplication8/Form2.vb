﻿Public Class Form2
    Private Sub ButtonSearch_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TarumanagaraBookstoreDataSet.Tabel_User' table. You can move, or remove it, as needed.
        Me.Tabel_UserTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet.Tabel_User)

    End Sub

    Private Sub ButtonAdmin_Click(sender As Object, e As EventArgs) Handles ButtonAdmin.Click
        Me.Dispose()
        Form3.Show()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = "Search By : ID" Then
            DataGridView1.Refresh()
            Tabel_UserTableAdapter1.SearchByID(TarumanagaraBookstoreDataSet.Tabel_User, TextBox1.Text)
        ElseIf ComboBox1.SelectedItem = "Search By : Judul Buku" Then
            DataGridView1.Refresh()
            Tabel_UserTableAdapter1.SearchByJudulBuku(TarumanagaraBookstoreDataSet.Tabel_User, TextBox1.Text)
        ElseIf ComboBox1.SelectedItem = "Search By : Status" Then
            DataGridView1.Refresh()
            Tabel_UserTableAdapter1.SearchByStatus(TarumanagaraBookstoreDataSet.Tabel_User, TextBox1.Text)
        Else
            DataGridView1.Refresh()
            TextBox1.Clear()
            Me.Tabel_UserTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet.Tabel_User)
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Dispose()
        Form1.Dispose()
        Form4.Dispose()
        Form3.Dispose()
        Form6.Dispose()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        Form6.Show()
    End Sub
End Class

Friend Class Class1
End Class
