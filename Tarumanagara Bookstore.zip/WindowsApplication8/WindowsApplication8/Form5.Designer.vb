﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.JudulbukuDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamapenulisDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamapenerbitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TanggalterbitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HargaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabelUserBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TarumanagaraBookstoreDataSet = New WindowsApplication8.TarumanagaraBookstoreDataSet()
        Me.Tabel_UserTableAdapter = New WindowsApplication8.TarumanagaraBookstoreDataSetTableAdapters.Tabel_UserTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TabelUserBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TarumanagaraBookstoreDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.JudulbukuDataGridViewTextBoxColumn, Me.NamapenulisDataGridViewTextBoxColumn, Me.NamapenerbitDataGridViewTextBoxColumn, Me.TanggalterbitDataGridViewTextBoxColumn, Me.HargaDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TabelUserBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(729, 328)
        Me.DataGridView1.TabIndex = 0
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'JudulbukuDataGridViewTextBoxColumn
        '
        Me.JudulbukuDataGridViewTextBoxColumn.DataPropertyName = "Judul_buku"
        Me.JudulbukuDataGridViewTextBoxColumn.HeaderText = "Judul_buku"
        Me.JudulbukuDataGridViewTextBoxColumn.Name = "JudulbukuDataGridViewTextBoxColumn"
        '
        'NamapenulisDataGridViewTextBoxColumn
        '
        Me.NamapenulisDataGridViewTextBoxColumn.DataPropertyName = "Nama_penulis"
        Me.NamapenulisDataGridViewTextBoxColumn.HeaderText = "Nama_penulis"
        Me.NamapenulisDataGridViewTextBoxColumn.Name = "NamapenulisDataGridViewTextBoxColumn"
        '
        'NamapenerbitDataGridViewTextBoxColumn
        '
        Me.NamapenerbitDataGridViewTextBoxColumn.DataPropertyName = "Nama_penerbit"
        Me.NamapenerbitDataGridViewTextBoxColumn.HeaderText = "Nama_penerbit"
        Me.NamapenerbitDataGridViewTextBoxColumn.Name = "NamapenerbitDataGridViewTextBoxColumn"
        '
        'TanggalterbitDataGridViewTextBoxColumn
        '
        Me.TanggalterbitDataGridViewTextBoxColumn.DataPropertyName = "Tanggal_terbit"
        Me.TanggalterbitDataGridViewTextBoxColumn.HeaderText = "Tanggal_terbit"
        Me.TanggalterbitDataGridViewTextBoxColumn.Name = "TanggalterbitDataGridViewTextBoxColumn"
        '
        'HargaDataGridViewTextBoxColumn
        '
        Me.HargaDataGridViewTextBoxColumn.DataPropertyName = "Harga"
        Me.HargaDataGridViewTextBoxColumn.HeaderText = "Harga"
        Me.HargaDataGridViewTextBoxColumn.Name = "HargaDataGridViewTextBoxColumn"
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        '
        'TabelUserBindingSource
        '
        Me.TabelUserBindingSource.DataMember = "Tabel_User"
        Me.TabelUserBindingSource.DataSource = Me.TarumanagaraBookstoreDataSet
        '
        'TarumanagaraBookstoreDataSet
        '
        Me.TarumanagaraBookstoreDataSet.DataSetName = "TarumanagaraBookstoreDataSet"
        Me.TarumanagaraBookstoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Tabel_UserTableAdapter
        '
        Me.Tabel_UserTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(639, 334)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(731, 364)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form5"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form5"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TabelUserBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TarumanagaraBookstoreDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TarumanagaraBookstoreDataSet As TarumanagaraBookstoreDataSet
    Friend WithEvents TabelUserBindingSource As BindingSource
    Friend WithEvents Tabel_UserTableAdapter As TarumanagaraBookstoreDataSetTableAdapters.Tabel_UserTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents JudulbukuDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamapenulisDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamapenerbitDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TanggalterbitDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HargaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
