﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ButtonAdmin = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.JudulbukuDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamapenulisDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NamapenerbitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TanggalterbitDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HargaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabelUserBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TarumanagaraBookstoreDataSet = New WindowsApplication8.TarumanagaraBookstoreDataSet()
        Me.Tabel_UserTableAdapter1 = New WindowsApplication8.TarumanagaraBookstoreDataSetTableAdapters.Tabel_UserTableAdapter()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TabelUserBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TarumanagaraBookstoreDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(13, 285)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(596, 23)
        Me.TextBox1.TabIndex = 1
        '
        'ButtonAdmin
        '
        Me.ButtonAdmin.Location = New System.Drawing.Point(661, 6)
        Me.ButtonAdmin.Name = "ButtonAdmin"
        Me.ButtonAdmin.Size = New System.Drawing.Size(75, 23)
        Me.ButtonAdmin.TabIndex = 2
        Me.ButtonAdmin.Text = "Admin"
        Me.ButtonAdmin.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.JudulbukuDataGridViewTextBoxColumn, Me.NamapenulisDataGridViewTextBoxColumn, Me.NamapenerbitDataGridViewTextBoxColumn, Me.TanggalterbitDataGridViewTextBoxColumn, Me.HargaDataGridViewTextBoxColumn, Me.StatusDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TabelUserBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(13, 35)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(723, 244)
        Me.DataGridView1.TabIndex = 4
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'JudulbukuDataGridViewTextBoxColumn
        '
        Me.JudulbukuDataGridViewTextBoxColumn.DataPropertyName = "Judul_buku"
        Me.JudulbukuDataGridViewTextBoxColumn.HeaderText = "Judul_buku"
        Me.JudulbukuDataGridViewTextBoxColumn.Name = "JudulbukuDataGridViewTextBoxColumn"
        '
        'NamapenulisDataGridViewTextBoxColumn
        '
        Me.NamapenulisDataGridViewTextBoxColumn.DataPropertyName = "Nama_penulis"
        Me.NamapenulisDataGridViewTextBoxColumn.HeaderText = "Nama_penulis"
        Me.NamapenulisDataGridViewTextBoxColumn.Name = "NamapenulisDataGridViewTextBoxColumn"
        '
        'NamapenerbitDataGridViewTextBoxColumn
        '
        Me.NamapenerbitDataGridViewTextBoxColumn.DataPropertyName = "Nama_penerbit"
        Me.NamapenerbitDataGridViewTextBoxColumn.HeaderText = "Nama_penerbit"
        Me.NamapenerbitDataGridViewTextBoxColumn.Name = "NamapenerbitDataGridViewTextBoxColumn"
        '
        'TanggalterbitDataGridViewTextBoxColumn
        '
        Me.TanggalterbitDataGridViewTextBoxColumn.DataPropertyName = "Tanggal_terbit"
        Me.TanggalterbitDataGridViewTextBoxColumn.HeaderText = "Tanggal_terbit"
        Me.TanggalterbitDataGridViewTextBoxColumn.Name = "TanggalterbitDataGridViewTextBoxColumn"
        '
        'HargaDataGridViewTextBoxColumn
        '
        Me.HargaDataGridViewTextBoxColumn.DataPropertyName = "Harga"
        Me.HargaDataGridViewTextBoxColumn.HeaderText = "Harga"
        Me.HargaDataGridViewTextBoxColumn.Name = "HargaDataGridViewTextBoxColumn"
        '
        'StatusDataGridViewTextBoxColumn
        '
        Me.StatusDataGridViewTextBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewTextBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewTextBoxColumn.Name = "StatusDataGridViewTextBoxColumn"
        '
        'TabelUserBindingSource
        '
        Me.TabelUserBindingSource.DataMember = "Tabel_User"
        Me.TabelUserBindingSource.DataSource = Me.TarumanagaraBookstoreDataSet
        '
        'TarumanagaraBookstoreDataSet
        '
        Me.TarumanagaraBookstoreDataSet.DataSetName = "TarumanagaraBookstoreDataSet"
        Me.TarumanagaraBookstoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Tabel_UserTableAdapter1
        '
        Me.Tabel_UserTableAdapter1.ClearBeforeFill = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Search By : ID", "Search By : Judul Buku", "Search By : Status", "Unsearch"})
        Me.ComboBox1.Location = New System.Drawing.Point(615, 285)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 34
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(542, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(113, 23)
        Me.Button1.TabIndex = 35
        Me.Button1.Text = "List Buku Baru"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 36
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(390, 6)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(146, 23)
        Me.Button3.TabIndex = 37
        Me.Button3.Text = "List Buku Baru via WCF"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(748, 321)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ButtonAdmin)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tarumanagara Bookstore"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TabelUserBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TarumanagaraBookstoreDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ButtonAdmin As Button
    Friend WithEvents TarumanagaraBookstoreDataSet1 As TarumanagaraBookstoreDataSet
    Friend WithEvents Tabel_UserTableAdapter As TarumanagaraBookstoreDataSetTableAdapters.Tabel_UserTableAdapter
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TarumanagaraBookstoreDataSet As TarumanagaraBookstoreDataSet
    Friend WithEvents TabelUserBindingSource As BindingSource
    Friend WithEvents Tabel_UserTableAdapter1 As TarumanagaraBookstoreDataSetTableAdapters.Tabel_UserTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents JudulbukuDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamapenulisDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NamapenerbitDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TanggalterbitDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HargaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
