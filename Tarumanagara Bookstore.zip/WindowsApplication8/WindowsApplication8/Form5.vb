﻿Public Class Form5
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TarumanagaraBookstoreDataSet.Tabel_User' table. You can move, or remove it, as needed.
        Me.Tabel_UserTableAdapter.NewBook(TarumanagaraBookstoreDataSet.Tabel_User)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Dispose()
        Form2.Show()
    End Sub
End Class