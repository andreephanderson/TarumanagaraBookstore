﻿Imports WindowsApplication8.ServiceReference1

Public Class Form6


    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim selectList As List(Of Class1) = New List(Of Class1)

        Dim service As New Service1Client()

        DataGridView1.DataSource = service.GetAllData()


        'List <Class1> selectList = new List<Class1>();

        'Service1Client service = new Service1Client();

        'DataGridView1.DataSource = service.GetAllData();

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class