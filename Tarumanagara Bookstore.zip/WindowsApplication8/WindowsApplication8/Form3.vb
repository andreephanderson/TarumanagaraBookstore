﻿Public Class Form3
    Dim jumlah As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            jumlah = List_AdminTableAdapter.Login(TextBox1.Text, TextBox2.Text)
            If jumlah = 1 Then
                Me.Dispose()
                Form4.Show()
            Else
                MessageBox.Show("Wrong username or password", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            MessageBox.Show("Error !", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TarumanagaraBookstoreDataSet.List_Admin' table. You can move, or remove it, as needed.
        Me.List_AdminTableAdapter.Fill(Me.TarumanagaraBookstoreDataSet.List_Admin)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Dispose()
        Form2.Show()
    End Sub
End Class