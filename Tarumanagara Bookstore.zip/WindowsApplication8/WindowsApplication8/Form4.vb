﻿Public Class Form4
    Dim status As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If MaskedTextBox4.Text > 0 Then
                status = "Ready"
            Else
                status = "Sold Out"
            End If
            Tabel_UserTableAdapter.Insert_User(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, MaskedTextBox1.Text, MaskedTextBox3.Text, status)
            Tabel_AdminTableAdapter1.Insert_Admin(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, MaskedTextBox1.Text, MaskedTextBox2.Text, MaskedTextBox3.Text, MaskedTextBox4.Text)
            MessageBox.Show("Book Inserted!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            MaskedTextBox1.Clear()
            MaskedTextBox2.Clear()
            MaskedTextBox3.Clear()
            MaskedTextBox4.Clear()
            DataGridView1.Refresh()
            Tabel_AdminTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet1.Tabel_Admin)
        Catch ex As Exception 
            MessageBox.Show("Field required", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TarumanagaraBookstoreDataSet1.Tabel_Admin' table. You can move, or remove it, as needed.
        Me.Tabel_AdminTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet1.Tabel_Admin)
        If TextBox6.TextLength = 0 Or TextBox7.TextLength = 0 Then
            Button3.Enabled = False
        Else
            Button3.Enabled = True
        End If
        ComboBox1.SelectedItem = 0
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            If MaskedTextBox7.Text > 0 Then
                status = "Ready"
            Else
                status = "Sold Out"
            End If
            Tabel_UserTableAdapter.Update_User(TextBox7.Text, MaskedTextBox6.Text, status, TextBox6.Text)
            Tabel_AdminTableAdapter1.Update_Admin(TextBox7.Text, MaskedTextBox5.Text, MaskedTextBox6.Text, MaskedTextBox7.Text, TextBox6.Text)
            TextBox6.Clear()
            TextBox7.Clear()
            MaskedTextBox5.Clear()
            MaskedTextBox6.Clear()
            MaskedTextBox7.Clear()
            DataGridView1.Refresh()
            Tabel_AdminTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet1.Tabel_Admin)
        Catch ex As Exception
            MessageBox.Show("Mohon Dicek data yang ingin anda update", "Notification", MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Tabel_UserTableAdapter.Delete_User(TextBox5.Text)
        Tabel_AdminTableAdapter1.Delete_Admin(TextBox5.Text)
        MessageBox.Show("Deleted!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        TextBox5.Clear()
        DataGridView1.Refresh()
        Tabel_AdminTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet1.Tabel_Admin)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = "Search By : ID" Then
            DataGridView1.Refresh()
            Tabel_AdminTableAdapter1.SearchByID(TarumanagaraBookstoreDataSet1.Tabel_Admin, TextBox8.Text)
        ElseIf ComboBox1.SelectedItem = "Search By : Judul Buku" Then
            DataGridView1.Refresh()
            Tabel_AdminTableAdapter1.SearchByJudulBuku(TarumanagaraBookstoreDataSet1.Tabel_Admin, TextBox8.Text)
        ElseIf ComboBox1.SelectedItem = "Search By : Kuantitas" Then
            Try
                DataGridView1.Refresh()
                Tabel_AdminTableAdapter1.SearchByKuantitas(TarumanagaraBookstoreDataSet1.Tabel_Admin, TextBox8.Text)
            Catch ex As Exception
                MessageBox.Show("Pastikan yang anda ketik berupa angka!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End Try

        Else
            DataGridView1.Refresh()
            TextBox8.Clear()
            Tabel_AdminTableAdapter1.Fill(Me.TarumanagaraBookstoreDataSet1.Tabel_Admin)
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Dispose()
        Form2.Show()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If TextBox1.TextLength = 0 Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True
        End If
    End Sub

    Private Sub MaskedTextBox7_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles MaskedTextBox7.MaskInputRejected
        Button3.Enabled = True
    End Sub

    Private Sub MaskedTextBox5_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles MaskedTextBox5.MaskInputRejected

        Button3.Enabled = True


    End Sub

    Private Sub MaskedTextBox6_MaskInputRejected(sender As Object, e As MaskInputRejectedEventArgs) Handles MaskedTextBox6.MaskInputRejected

        Button3.Enabled = True


    End Sub
End Class